#coding:utf-8

TYPE_RECYCLE = 0
TYPE_PROVIDE = 1