CMD=`../protoc/bin/protoc --python_out=../code/proto *.proto`

CMD=`../protoc/bin/protoc -ocardgame.desc *.proto`

#CMD=`cp poker.desc ../client/res/raw`

#CMD=`../protoc/bin/protoc --java_out=../client/src *.proto`
