# -*- coding: utf-8 -*-

MAIL_TEMP_CHARGE_SUCCESS = u"""
尊敬的%s，您已充值%d元，获得了%d个钻石，已加到您的账号，请查收。
"""

