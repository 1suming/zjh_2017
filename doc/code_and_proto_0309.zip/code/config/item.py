# -*- coding: utf-8 -*-
__author__ = 'Administrator'

ITEM_MAP = {
    'horn':(1,'use_horn'),
    'kick':(2,'use_kick'),
    'exp_1':(3,'use_exp_1'),
    'exp_10':(4,'use_exp_2'),
    # 'tgold':(5,'use_tgold'),
}


ITEM_CONF = {
    3:(1,),
    4:(10,)
}

DEFAULT_USER_ITEM = (4,2)
