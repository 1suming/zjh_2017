# -*- coding: utf-8 -*-
__author__ = 'Administrator'

RANK_WEALTH_TOP = 20
RANK_CHARGE_TOP = 20
RANK_MAKE_MONEY_TOP = 20

RANK_FAKE_LEN = 20

RANK_FAKE_CHARGE_ENABLE = False
RANK_FAKE_CHARGE = [
    {'id':1,'uid':20120,'nick':'haha1','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':3,'rank_reward':'','charm':0,'money_maked':0},
    {'id':2,'uid':20220,'nick':'haha2','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':6,'rank_reward':'','charm':0,'money_maked':0},
    {'id':3,'uid':20320,'nick':'haha3','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':4,'rank_reward':'','charm':0,'money_maked':0},
    {'id':4,'uid':20420,'nick':'haha4','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':3,'rank_reward':'','charm':0,'money_maked':0},
    {'id':5,'uid':20520,'nick':'haha5','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':2,'rank_reward':'','charm':0,'money_maked':0},
    {'id':6,'uid':20620,'nick':'haha6','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':1,'rank_reward':'','charm':0,'money_maked':0},
    {'id':7,'uid':20720,'nick':'haha7','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':2,'rank_reward':'','charm':0,'money_maked':0},
    {'id':8,'uid':20820,'nick':'haha8','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':1,'rank_reward':'','charm':0,'money_maked':0},
    {'id':9,'uid':20920,'nick':'haha9','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':1,'rank_reward':'','charm':0,'money_maked':0},
    {'id':10,'uid':21020,'nick':'haha10','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':2,'rank_reward':'','charm':0,'money_maked':0},
]


RANK_FAKE_MAKE_MONEYD_ENABLE = True
RANK_FAKE_MAKE_MONEYD = [
    {'id':1,'uid':20120,'nick':'haha1','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':3,'rank_reward':'','charm':0,'money_maked':0},
    {'id':2,'uid':20220,'nick':'haha2','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':6,'rank_reward':'','charm':0,'money_maked':0},
    {'id':3,'uid':20320,'nick':'haha3','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':4,'rank_reward':'','charm':0,'money_maked':0},
    {'id':4,'uid':20420,'nick':'haha4','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':3,'rank_reward':'','charm':0,'money_maked':0},
    {'id':5,'uid':20520,'nick':'haha5','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':2,'rank_reward':'','charm':0,'money_maked':0},
    {'id':6,'uid':20620,'nick':'haha6','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':1,'rank_reward':'','charm':0,'money_maked':0},
    {'id':7,'uid':20720,'nick':'haha7','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':2,'rank_reward':'','charm':0,'money_maked':0},
    {'id':8,'uid':20820,'nick':'haha8','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':1,'rank_reward':'','charm':0,'money_maked':0},
    {'id':9,'uid':20920,'nick':'haha9','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':1,'rank_reward':'','charm':0,'money_maked':0},
    {'id':10,'uid':21020,'nick':'haha10','avatar':'http://192.168.2.75:5000/static/upload/10023_867356020226898_tmp_avatar.png','gold':100,'vip':2,'rank_reward':'','charm':0,'money_maked':0},
]

