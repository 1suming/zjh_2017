# -*- coding: utf-8 -*-
__author__ = 'Administrator'


REWARD_PLAY_ROUND = [
    (3,2400,4800),
    (6,4500,9000),
    (12,10000,20000),
    (20,20000,40000),
]


REWARD_CONF = {
    'first_login':{'id':8,'type':0,'diamond':0,'gold':0,'items':'4-1','gifts':'','received_time':'','profile':''},
    'update_nick':{'id':9,'type':0,'diamond':0,'gold':20000,'items':'','gifts':'','received_time':'','profile':''},
    'update_avatar':{'id':10,'type':0,'diamond':0,'gold':20000,'items':'','gifts':'','received_time':'','profile':''},

}


