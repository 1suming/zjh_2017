__all__ = ['access_pb2','game_pb2','friend_pb2','bag_pb2','bank_pb2','chat_pb2','hall_pb2','mail_pb2' \
     ,'rank_pb2','reward_pb2','trade_pb2','vip_pb2']