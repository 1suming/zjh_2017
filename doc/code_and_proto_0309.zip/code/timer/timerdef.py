#coding: utf8

TIMER_OBJECT_ROLE                           = 1

# ---------------------------------------------------------

TIMER_EVENT_INCREASE_POWER                  = 1

