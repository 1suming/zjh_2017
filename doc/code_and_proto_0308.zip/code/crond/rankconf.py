# -*- coding: utf-8 -*-
__author__ = 'Administrator'

RANK_REWARD = {
    # 金币，钻石，vip经验，[(道具1,数量),(道具2,数量),]
    'rank_charge_top':(10000,1000,1000,[(1,12)],),
    'rank_gold_top':(10000,1000,1000,[(1,12)],),
    'rank_make_money_top':(10000,1000,1000,[(1,12)],),
}