#!/usr/bin/ env python
# coding:utf-8
__author__ = 'Administrator'

from hallobject import MessageObject
from config import var

class HallSys:

    def __init__(self, service):
        self.service = service


    def push_sys_notice(self,message):
        self.notification()

    def get_onlines(self):
        return self.service.redis.hkeys('online')

    def notification(self, message, type):
        MessageObject.push_message(self.service, self.get_onlines(), var.PUSH_TYPE['sys_brodacast'],message, type)
