# -*- coding: utf-8 -*-
__author__ = 'Administrator'


SIGN_CONF  = {
    0:{'gold':0},
    1:{'gold':10000,},
    2:{'gold':20000,},
    3:{'gold':20000,},
    4:{'gold':30000,},
    5:{'gold':30000,},
    6:{'gold':50000,},
    7:{'items':(10,1,'horn'),},
    14:{'items':(10,2,'kick'),},
    21:{'items':(10,3,'use_exp_1'),},
    28:{'items':(2,4,'use_exp_10'),},
}
SYS_MAX_SIGN_DAY = 7

SIGN_MONTH_LUCK = {
    7:(10,1,'horn'),
    14:(10,2,'kick'),
    21:(10,3,'use_exp_1'),
    28:(2,4,'use_exp_10'),
}